# Submission Checklist

- [x] Runnable `index.html` entry point.
- [x] Desktop keyboard controls.
- [x] Mobile on-screen controls.
- [x] Organized source code and CSS.
- [x] Organized `assets/audio/` directory.
- [x] Reward-Damage-End loop documented and implemented.
- [x] Master chronological AI prompt log.
- [x] Error-recovery examples.
- [x] 200–300 word analytical reflection.
- [x] Gameplay/concept references.
- [x] Generative AI tool inventory.
- [x] Asset attribution sheet.
- [ ] Replace audio-generator placeholders with the exact AI audio service/model and license terms if your instructor requires exact vendor attribution.
