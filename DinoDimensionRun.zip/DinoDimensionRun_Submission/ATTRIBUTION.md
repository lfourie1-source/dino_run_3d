# Asset Attribution

## Code and Game Design
**Asset:** Game source code and procedural visuals  
**Files:** `index.html`, `src/game.js`, `assets/css/styles.css`  
**Creator:** Project creator with OpenAI ChatGPT (GPT-5.6 Sol) used as an AI coding assistant  
**Notes:** Human-directed iterative development and play-testing. No third-party game source code, sprites, textures, or 3D models are included.

## Audio Assets

### Background Music
**File:** `assets/audio/background.mp3`  
**Original uploaded filename:** `Lobby_Lounge_Runner_2026-10-06T225606.mp3`  
**Source:** AI-generated audio supplied by the project creator  
**Generator/license:** Exact generator was not recorded in the development conversation. Add the actual service/model and applicable license or commercial-use terms before final submission if required.

### Death Sound
**File:** `assets/audio/dying.mp3`  
**Original uploaded filename:** `dying.mp3`  
**Source:** AI-generated audio supplied by the project creator  
**Generator/license:** Exact generator was not recorded; verify the service terms used to create it.

### Jump Sound
**File:** `assets/audio/jump.mp3`  
**Original uploaded filename:** `make_a_jump_sound_af_#3-1791332940468.mp3`  
**Source:** AI-generated audio supplied by the project creator  
**Processing:** Silence after the effect was trimmed for responsive playback.  
**Generator/license:** Exact generator was not recorded; verify the service terms used to create it.

### Victory Sound
**File:** `assets/audio/victory.mp3`  
**Original uploaded filename:** `make_a_victory_sound_#3-1791333802369.mp3`  
**Source:** AI-generated audio supplied by the project creator  
**Generator/license:** Exact generator was not recorded; verify the service terms used to create it.

## Concept Reference
**Reference:** Chrome Offline Dinosaur Game / Chrome Dino  
**Use:** General endless-runner gameplay inspiration only.  
**Copied assets/code:** None.

## License Accuracy Note
Because the exact AI audio generator is not identifiable from file metadata or the development chat, this package intentionally does **not** claim a CC BY license or specific commercial license. Entering a made-up license would be inaccurate. Replace the placeholders with the actual generating service and terms if your rubric requires formal license language.
