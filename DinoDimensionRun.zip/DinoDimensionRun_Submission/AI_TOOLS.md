# Generative AI Tools and Models Used

## Coding / Design Assistance
**OpenAI ChatGPT — GPT-5.6 Sol**

Used for:
- HTML/CSS/JavaScript game prototyping.
- Procedural obstacle and difficulty-system design.
- Collision and scoring logic.
- Debugging reversed controls and safe-lane exploits.
- Audio integration.
- Project packaging and documentation.

The human creator repeatedly play-tested the output, identified failures, selected the art direction, chose the gameplay rules, and requested revisions.

## Audio Generation
The project creator supplied four AI-generated audio assets during development:
- background music
- death sound
- jump sound
- victory sound

**Important attribution note:** the exact audio-generation product/model name was not captured in the development chat. Do not invent a vendor name. If your instructor requires the exact tool and license, replace the placeholder entry in `ATTRIBUTION.md` / `ASSET_ATTRIBUTION.csv` with the service you actually used to generate those files and its applicable terms.

## Visual Generation
No external generative-image assets are used in the submitted game. The dinosaur, environment, obstacles, coins, and biome visuals are drawn by code in `src/game.js`.
